import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trusted',
  templateUrl: './trusted.component.html',
  styleUrls: ['./trusted.component.css']
})
export class TrustedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
